# Configuration Guide

This guide explains how to customize the AI Development Toolkit for your Android project.

## Table of Contents

1. [Quick Start Checklist](#quick-start-checklist)
2. [Critical Configuration Files](#critical-configuration-files)
3. [Customizing AI Rules](#customizing-ai-rules)
4. [Customizing Project Map](#customizing-project-map)
5. [Customizing Golden Examples](#customizing-golden-examples)
6. [Customizing Quality Checks](#customizing-quality-checks)
7. [Advanced Configuration](#advanced-configuration)

## Quick Start Checklist

After running `install.sh`, customize these files in order:

- [ ] `docs/ai/PROJECT_MAP.md` - Map your project structure
- [ ] `docs/ai/AI_RULES.md` - Define architecture boundaries
- [ ] `docs/ai/GOLDEN_EXAMPLES.md` - Point to best implementations
- [ ] `docs/ai/DEFINITION_OF_DONE.md` - Set quality gates
- [ ] `tools/check-fast.sh` - Verify quality check commands (optional)
- [ ] `tools/check.sh` - Verify build command (optional)

## Critical Configuration Files

### Priority 1: Must Customize

These files directly impact AI code generation quality:

#### 1. `docs/ai/PROJECT_MAP.md`

**Why**: Tells AI exactly where to place new files and which patterns to follow.

**What to update**:

```markdown
## Modules
- `:app` — Your app module description
- `:core` — If you have additional modules
- `:feature-login` — Feature modules

## Package layout
- `com.yourcompany.yourapp`
  - `ui/<feature>/` — Your screen organization
  - `data/` — Your data layer structure
  - `domain/` — If you have a domain layer
  - `di/` — Dependency injection location

## Key entry points
- Application class: `com.yourcompany.yourapp.YourApplication`
- Main activity: `com.yourcompany.yourapp.MainActivity`
- Navigation graph: `com.yourcompany.yourapp.navigation.AppNavigation`
- DI modules: Point to your Hilt/Koin modules

## Golden examples
- Best ViewModel: `ui/home/HomeViewModel.kt`
- Best Screen: `ui/home/HomeScreen.kt`
- Best Repository: `data/repository/UserRepository.kt`
```

**Template variables** (if set during installation):
- `{{PROJECT_NAME}}` → Your project name
- `{{PACKAGE_NAME}}` → Your base package
- `{{MODULES}}` → Your module list
- `{{PACKAGE_STRUCTURE}}` → Your package organization
- `{{KEY_ENTRY_POINTS}}` → Your main classes
- `{{GOLDEN_EXAMPLES}}` → Your best examples

#### 2. `docs/ai/AI_RULES.md`

**Why**: Defines architecture boundaries and coding standards.

**What to update**:

**Architecture Section (§1)**:
```markdown
## 1) Architecture boundaries (YOUR_ARCHITECTURE)

- **UI layer**: [Your UI framework - Compose/XML, navigation approach]
- **ViewModel layer**: [Your state management - MVI/MVVM/other]
- **Domain layer**: [If you have use cases, describe them]
- **Data layer**: [Your data sources - Room/Retrofit/DataStore]

Rules:
- [Your specific architectural rules]
- [Your layer communication rules]
```

**File Placement Section (§2)**:
```markdown
## 2) File placement rules
- New UI screens go in: [your location]
- ViewModels live in: [your location]
- Repositories live in: [your location]
- Use cases live in: [your location if applicable]
- DI modules live in: [your location]
```

**Naming Conventions Section (§3)**:
```markdown
## 3) Naming conventions
- Screen composables: [YourPattern - e.g., FeatureNameScreen]
- ViewModels: [YourPattern]
- UI state: [YourPattern]
- UI events: [YourPattern]
- Use cases: [YourPattern if you have domain layer]
```

**Error Handling Section (§4)**:
```markdown
## 4) Error handling
- [Your error modeling approach - Result/Either/sealed classes]
- [Your UI error state pattern]
- [Your logging approach - Timber/custom]
```

**Template variables**:
- `{{PROJECT_NAME}}` → Your project name
- `{{ARCHITECTURE}}` → MVVM/MVI/MVP/Clean
- `{{PACKAGE_NAME}}` → Your base package

#### 3. `docs/ai/GOLDEN_EXAMPLES.md`

**Why**: AI copies patterns from your best code instead of inventing new ones.

**What to update**:

Replace placeholder paths with your actual best implementations:

```markdown
## UI
- `app/src/main/java/com/yourcompany/yourapp/ui/home/HomeScreen.kt`
- `app/src/main/java/com/yourcompany/yourapp/ui/profile/ProfileScreen.kt`

## ViewModel
- `app/src/main/java/com/yourcompany/yourapp/ui/home/HomeViewModel.kt`
  - Good example of state management
  - Shows proper coroutine usage
  - Demonstrates error handling

## Data / Repository
- `app/src/main/java/com/yourcompany/yourapp/data/repository/UserRepository.kt`
  - Flow-based reactive updates
  - Proper error mapping
  - Cache strategy

## Domain (if applicable)
- `app/src/main/java/com/yourcompany/yourapp/domain/usecase/GetUserUseCase.kt`

## DI / Hilt Modules
- `app/src/main/java/com/yourcompany/yourapp/di/DataModule.kt`
- `app/src/main/java/com/yourcompany/yourapp/di/NetworkModule.kt`

## Testing
- `app/src/test/java/com/yourcompany/yourapp/ui/home/HomeViewModelTest.kt`
  - Shows proper test structure
  - Good use of test doubles
  - Covers edge cases
```

**Tips**:
- Choose files that follow your preferred patterns
- Include comments explaining what makes them good examples
- Update as your codebase evolves

### Priority 2: Should Review

#### 4. `docs/ai/DEFINITION_OF_DONE.md`

**Why**: Defines when a feature is truly complete.

**What to customize**:

```markdown
## Required
- Change Contract approved and followed
- `tools/check-fast.sh` passes locally
- CI passes `tools/check.sh`
- Feature acceptance criteria satisfied
- [Your additional requirements]

## Recommended
- ViewModel unit tests for new/changed state logic
- [Your test coverage requirements]
- [Your documentation requirements]
- [Your code review requirements]
```

**Common additions**:
- Code coverage thresholds (e.g., "80% coverage on new code")
- Specific test types (integration tests, UI tests)
- Documentation requirements (KDoc comments, README updates)
- Design review requirements
- Accessibility checks

#### 5. `docs/ai/WORKFLOW.md`

**Why**: Documents the development workflow for your team.

**What to customize**:

- Update shell aliases to match your preferences
- Add team-specific workflow steps
- Document your CI/CD integration
- Add project-specific examples

**Optional additions**:
```markdown
## Team Conventions
- PR template requirements
- Branch naming: `feature/`, `bugfix/`, `hotfix/`
- Commit message format

## CI Integration
- Pre-commit hooks: `pre-commit install`
- CI runs: `check.sh` on all PRs
- Deployment: [your deployment process]
```

## Customizing Quality Checks

### For Standard Android Projects

The default scripts should work out-of-the-box if you use:
- Spotless for formatting
- Detekt for static analysis
- Android Lint
- JUnit for testing

### Customizing `tools/check-fast.sh`

Open `tools/check-fast.sh` and modify the Gradle tasks:

```bash
#!/usr/bin/env bash
set -euo pipefail

ROOT=$(git rev-parse --show-toplevel)
cd "$ROOT"

# Verify allowlist
./tools/ai-allowlist-check.sh

# Run your custom checks
echo "Running quality checks..."

# Example: Replace with your project's tasks
./gradlew spotlessCheck    # Code formatting
./gradlew detekt           # Static analysis
./gradlew lintDebug        # Android Lint
./gradlew testDebugUnitTest  # Unit tests

# Add your custom checks:
# ./gradlew your-custom-task
# npm run lint  # If you have JS/TS code
# python scripts/check.py  # Custom validation

echo "✓ All checks passed!"
```

### Customizing `tools/check.sh`

Open `tools/check.sh` and modify the build command:

```bash
#!/usr/bin/env bash
set -euo pipefail

ROOT=$(git rev-parse --show-toplevel)
cd "$ROOT"

# Run fast checks first
./tools/check-fast.sh

# Then build
echo "Building application..."
./gradlew assembleDebug  # Or your preferred build variant

# Add additional checks:
# ./gradlew connectedAndroidTest  # Instrumented tests
# ./gradlew bundleRelease  # Release build

echo "✓ All checks and build passed!"
```

### Common Customizations

**Adding code coverage**:
```bash
./gradlew testDebugUnitTestCoverage
./gradlew jacocoTestReport
```

**Adding instrumented tests**:
```bash
./gradlew connectedDebugAndroidTest
```

**Adding custom Gradle tasks**:
```bash
./gradlew your-custom-task
```

**Multi-module projects**:
```bash
# Check specific modules
./gradlew :app:testDebugUnitTest
./gradlew :core:test
./gradlew :feature-login:lintDebug
```

## Advanced Configuration

### Customizing AI Context Generation

The `ai-context.sh` script generates context from specific files. To customize what's included:

1. **Edit `tools/ai-context.sh`**:

```bash
# Find this section and modify files read:
cat "$ROOT/docs/ai/AI_RULES.md" | head -n 260
cat "$ROOT/docs/ai/PROJECT_MAP.md" | head -n 260
# Add your custom files:
cat "$ROOT/docs/ARCHITECTURE.md" | head -n 260
```

2. **Add project-specific context**:

```bash
# Add after existing context sections:
echo "## Custom Project Context"
echo ""
cat "$ROOT/docs/your-custom-doc.md"
```

### Customizing Session Templates

Edit `.ai/sessions/SESSION_TEMPLATE.md` to match your workflow:

```markdown
# Session: {{FEATURE_NAME}}
Date: {{DATE}}

## Objective
[What are we building?]

## Acceptance Criteria
- [ ] [Your standard criteria]
- [ ] Tests pass
- [ ] Documentation updated

## Technical Approach
[Architecture decisions]

## Change Contract Status
- [ ] Drafted
- [ ] Approved by: [Your approval process]
- [ ] Implemented

## Progress Log
### [Date/Time]
- [What was done]
- [What's next]
```

### Customizing Change Contract Template

Edit `.ai/prompts/CHANGE_CONTRACT_TEMPLATE.md`:

```yaml
change_contract:
  feature: "{{FEATURE_NAME}}"
  session: "{{SESSION_FILE}}"
  
  # Add your custom fields:
  estimated_effort: "{{EFFORT}}"
  assigned_to: "{{DEVELOPER}}"
  
  files_to_modify:
    - path: "app/src/.../File.kt"
      reason: "Why modifying"
      # Add your fields:
      complexity: "low|medium|high"
  
  files_to_create:
    - path: "app/src/.../NewFile.kt"
      purpose: "What this file does"
      # Add your fields:
      template: "which template to use"
```

### Customizing Master Prompt

Edit `.ai/prompts/MASTER_PROMPT.md` to adjust AI behavior:

```markdown
# Add your project-specific instructions:

## Code Review Standards
- All PRs require 2 approvals
- No TODOs in production code
- All public APIs must have KDoc

## Performance Requirements
- All database queries must have indexes
- Image loading must use Coil
- Network calls must have timeout of 30s

## Security Requirements
- No API keys in code
- All network calls use HTTPS
- Sensitive data must be encrypted
```

## Project-Specific Patterns

### Multi-Module Projects

Update `PROJECT_MAP.md`:

```markdown
## Modules
- `:app` — Main application module
- `:core:ui` — Shared UI components
- `:core:data` — Shared data layer
- `:core:network` — Networking
- `:feature:login` — Login feature
- `:feature:home` — Home feature

## Module Dependencies
- Feature modules depend on core modules only
- No feature-to-feature dependencies
- App module depends on all features
```

### Clean Architecture

Update `AI_RULES.md`:

```markdown
## 1) Architecture boundaries (Clean Architecture)

Layers (from outer to inner):
- **Presentation**: UI (Compose), ViewModels, UI state
- **Domain**: Use cases, entities, repository interfaces
- **Data**: Repository implementations, data sources, DTOs

Rules:
- Dependencies point inward only
- Domain layer has no Android dependencies
- Use cases orchestrate business logic
- Presentation layer only holds UI logic
```

### MVI Architecture

Update `AI_RULES.md`:

```markdown
## 1) Architecture boundaries (MVI)

- **View**: Composables that render UI state
- **Intent**: Sealed class of user actions
- **Model**: Reducer that processes intents and updates state
- **State**: Single immutable UI state

Rules:
- All user interactions emit intents
- State updates only via reducer
- Side effects handled separately (Effect sealed class)
```

## Validation

After customizing, validate your configuration:

### 1. Generate AI Context

```bash
./tools/ai-context.sh
```

Check `.ai/context/AI_CONTEXT.md`:
- Contains your project name
- Contains your package structure
- Contains your golden examples
- File size is reasonable (not empty, not too large)

### 2. Run Quality Checks

```bash
./tools/check-fast.sh
```

Should pass on clean project. If it fails:
- Check Gradle task names match your project
- Ensure dependencies are configured
- Review error messages for missing plugins

### 3. Test Session Creation

```bash
./tools/ai-start.sh test-config
```

Should create `.ai/sessions/YYYY-MM-DD__test-config.md` with correct content.

### 4. Verify Allowlist Checking

```bash
# Make a test change
touch test-file.txt

# Check allowlist (should fail - file not in contract)
./tools/ai-allowlist-check.sh || echo "Correctly detected unauthorized change"

# Clean up
rm test-file.txt
git checkout .
```

## Common Configuration Patterns

### Kotlin Multiplatform

```markdown
## Modules
- `:shared` — Shared KMP code
- `:androidApp` — Android-specific code
- `:iosApp` — iOS-specific code (not managed by this toolkit)

## Package layout (shared)
- `com.yourcompany.shared`
  - `commonMain/` — Common code
  - `androidMain/` — Android-specific
```

### Compose + XML Mix

```markdown
## UI Patterns
- New features: Use Jetpack Compose
- Legacy screens: XML layouts (migrate gradually)
- Navigation: Navigation Component (supports both)

## File placement
- Compose screens: `ui/<feature>/<Feature>Screen.kt`
- XML layouts: `res/layout/fragment_<feature>.xml`
- Fragments: `ui/<feature>/<Feature>Fragment.kt`
```

### Modularized by Feature

```markdown
## Module Structure
Each feature module contains:
- `ui/` — Screens and ViewModels
- `data/` — Feature-specific repositories
- `di/` — Feature DI module

## Cross-feature Communication
- Via shared `:core:domain` module
- Use cases define boundaries
- Events via shared event bus
```

## Troubleshooting Configuration

### AI generates files in wrong location

**Problem**: AI puts files in unexpected directories.

**Solution**: Update `docs/ai/PROJECT_MAP.md` with exact paths:
```markdown
## File placement examples
- Screens: `app/src/main/java/com/example/app/ui/home/HomeScreen.kt`
- ViewModels: `app/src/main/java/com/example/app/ui/home/HomeViewModel.kt`
```

### AI uses wrong architecture patterns

**Problem**: AI generates MVI code when you use MVVM.

**Solution**: 
1. Update `docs/ai/AI_RULES.md` architecture section
2. Update `docs/ai/GOLDEN_EXAMPLES.md` with your patterns
3. Be explicit in session prompt: "Follow MVVM pattern from AI_RULES.md"

### Quality checks fail immediately

**Problem**: `check-fast.sh` fails even on clean project.

**Solution**:
1. Run individual Gradle tasks to identify issue:
   ```bash
   ./gradlew spotlessCheck
   ./gradlew detekt
   ./gradlew lintDebug
   ./gradlew testDebugUnitTest
   ```
2. Fix configuration issues in `build.gradle.kts`
3. Update `check-fast.sh` to match your actual Gradle tasks

### Context generation is slow

**Problem**: `ai-context.sh` takes too long.

**Solution**: Reduce lines read from large files:
```bash
# In ai-context.sh, change head -n 260 to smaller number:
cat "$ROOT/docs/ai/AI_RULES.md" | head -n 100
```

## Next Steps

After configuration:

1. **Test the workflow**: Run through a full feature implementation
2. **Train your team**: Share workflow with team members
3. **Iterate**: Update configuration based on what works
4. **Document deviations**: Track project-specific rules in `.ai/decisions.md`

For more help, see [TROUBLESHOOTING.md](TROUBLESHOOTING.md).
