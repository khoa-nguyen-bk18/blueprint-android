# Troubleshooting Guide

Common issues and solutions for the AI Development Toolkit.

## Table of Contents

1. [Installation Issues](#installation-issues)
2. [Git Issues](#git-issues)
3. [CLI Tool Issues](#cli-tool-issues)
4. [Script Execution Issues](#script-execution-issues)
5. [Context Generation Issues](#context-generation-issues)
6. [Quality Check Issues](#quality-check-issues)
7. [Session Management Issues](#session-management-issues)
8. [Allowlist Validation Issues](#allowlist-validation-issues)
9. [Ticket Generator Issues](#ticket-generator-issues)

## Installation Issues

### "Cannot find toolkit structure"

**Problem**: `install.sh` fails with "Cannot find toolkit structure."

**Solution**:
```bash
# Ensure you're running from the correct location
cd ai-dev-toolkit/scripts
./install.sh

# Or provide absolute path
/path/to/ai-dev-toolkit/scripts/install.sh
```

### "Invalid project directory"

**Problem**: Installer can't find or access project directory.

**Solution**:
```bash
# Use absolute path
/Users/yourname/projects/your-android-app

# Or tilde expansion
~/projects/your-android-app

# Make sure directory exists and is readable
ls -la /path/to/project
```

### Installation hangs during package installation

**Problem**: `brew install gum` or `apt install fzf` hangs.

**Solution**:
```bash
# Update package manager first
brew update  # macOS
sudo apt-get update  # Linux

# Install manually if needed
brew install gum fzf  # macOS
sudo apt-get install gum fzf  # Ubuntu/Debian

# Skip installation in installer by selecting 'n'
```

### "Toolkit directory already exists"

**Problem**: Previous installation exists.

**Solution**:
```bash
# Option 1: Remove old installation
rm -rf tools/ai-dev-toolkit
# Then run install.sh again

# Option 2: Choose 'n' when asked to overwrite
# Then manually copy individual scripts you need
```

## Git Issues

### "Not a git repository"

**Problem**: Scripts fail with "fatal: not a git repository"

**Solution**:
```bash
# Initialize git in your project
cd /path/to/your/project
git init
git add .
git commit -m "Initial commit"

# Or run installer, it will offer to initialize
```

### "Cannot find git in PATH"

**Problem**: `git` command not found.

**Solution**:
```bash
# Check if git is installed
which git

# Install git if missing
# macOS
xcode-select --install
brew install git

# Ubuntu/Debian
sudo apt-get install git

# Verify installation
git --version
```

### Scripts can't find project root

**Problem**: `git rev-parse --show-toplevel` fails.

**Solution**:
```bash
# Ensure you're inside a git repository
cd /path/to/your/project
git rev-parse --show-toplevel  # Should print project root

# If you're in a subdirectory, this is normal - scripts navigate to root
```

## CLI Tool Issues

### "Command not found: gum"

**Problem**: `gum` is not installed or not in PATH.

**Solution**:
```bash
# Install gum
# macOS
brew install gum

# Ubuntu/Debian
sudo mkdir -p /etc/apt/keyrings
curl -fsSL https://repo.charm.sh/apt/gpg.key | sudo gpg --dearmor -o /etc/apt/keyrings/charm.gpg
echo "deb [signed-by=/etc/apt/keyrings/charm.gpg] https://repo.charm.sh/apt/ * *" | sudo tee /etc/apt/sources.list.d/charm.list
sudo apt update
sudo apt install gum

# Verify installation
gum --version
```

### "Command not found: fzf"

**Problem**: `fzf` is not installed or not in PATH.

**Solution**:
```bash
# Install fzf
# macOS
brew install fzf

# Ubuntu/Debian
sudo apt-get install fzf

# Alternative: Install from git
git clone --depth 1 https://github.com/junegunn/fzf.git ~/.fzf
~/.fzf/install

# Verify installation
fzf --version
```

### "Command not found: copilot"

**Problem**: GitHub Copilot CLI is not installed.

**Solution**:
```bash
# Option 1: Install GitHub Copilot CLI
# Follow instructions at: https://github.com/github/gh-copilot

# Option 2: Use manual workflow instead
./tools/ai-start.sh feature-name  # Instead of ai-start-copilot.sh
./tools/ai-resume.sh              # Instead of ai-resume-copilot.sh
```

### Homebrew not found (macOS)

**Problem**: `brew: command not found`

**Solution**:
```bash
# Install Homebrew
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Follow post-installation instructions to add brew to PATH
echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> ~/.zprofile
eval "$(/opt/homebrew/bin/brew shellenv)"

# Verify
brew --version
```

## Script Execution Issues

### "Permission denied" when running scripts

**Problem**: Scripts are not executable.

**Solution**:
```bash
# Make scripts executable
chmod +x tools/*.sh

# Or specific script
chmod +x tools/ai-start.sh

# Verify
ls -la tools/*.sh  # Should show -rwxr-xr-x
```

### "Bad interpreter: /bin/bash^M"

**Problem**: Scripts have Windows line endings (CRLF).

**Solution**:
```bash
# Convert line endings to Unix (LF)
# Install dos2unix if needed
brew install dos2unix  # macOS
sudo apt-get install dos2unix  # Linux

# Convert scripts
dos2unix tools/*.sh

# Or use sed
sed -i 's/\r$//' tools/*.sh
```

### Scripts fail with "set -u: unbound variable"

**Problem**: Script encounters undefined variable.

**Solution**:
```bash
# This is usually a bug in customization
# Check if you modified scripts and introduced undefined variables

# Temporarily disable strict mode for debugging
# Edit the script and change:
set -euo pipefail
# To:
set -eo pipefail  # Removed -u

# Then run with debugging
bash -x tools/your-script.sh
```

## Context Generation Issues

### `ai-context.sh` produces empty file

**Problem**: `.ai/context/AI_CONTEXT.md` is empty or nearly empty.

**Solution**:
```bash
# Check required files exist
ls -la docs/ai/AI_RULES.md
ls -la docs/ai/PROJECT_MAP.md
ls -la .ai/prompts/MASTER_PROMPT.md

# Run with debugging to see what fails
bash -x tools/ai-context.sh

# Check file permissions
ls -la docs/ai/
ls -la .ai/prompts/

# Verify you're in project root
pwd
git rev-parse --show-toplevel
```

### "Cannot find docs/ai/AI_RULES.md"

**Problem**: Required documentation files missing.

**Solution**:
```bash
# Re-run installer to restore templates
cd tools/ai-dev-toolkit
./scripts/install.sh

# Or manually create from templates
cp tools/ai-dev-toolkit/templates/docs/ai/AI_RULES.md docs/ai/
cp tools/ai-dev-toolkit/templates/docs/ai/PROJECT_MAP.md docs/ai/
```

### Context file is too large

**Problem**: Generated context exceeds AI token limits.

**Solution**:
```bash
# Edit ai-context.sh to reduce lines read
vim tools/ai-context.sh

# Change head -n 260 to smaller number
cat "$ROOT/docs/ai/AI_RULES.md" | head -n 100  # Reduced from 260

# Or exclude session history
# Comment out this section:
# if [[ -d "$ROOT/.ai/sessions" ]]; then
#     ...
# fi
```

### Context generation is slow

**Problem**: Takes more than 30 seconds to generate.

**Solution**:
```bash
# Check if git status is slow
time git status

# Reduce lines read from files (see above)

# Check for very large session files
du -sh .ai/sessions/*
# If any >1MB, archive old sessions:
mkdir -p .ai/sessions/archive
mv .ai/sessions/2024-*.md .ai/sessions/archive/
```

## Quality Check Issues

### `check-fast.sh` fails immediately

**Problem**: Quality checks fail on clean project.

**Solution**:
```bash
# Run individual checks to isolate problem
./gradlew spotlessCheck  # Code formatting
./gradlew detekt         # Static analysis
./gradlew lintDebug      # Android Lint
./gradlew testDebugUnitTest  # Unit tests

# Common fixes:

# 1. Spotless not configured
# Add to app/build.gradle.kts:
plugins {
    id("com.diffplug.spotless") version "6.23.3"
}

# 2. Detekt not configured
# Add to app/build.gradle.kts:
plugins {
    id("io.gitlab.arturbosch.detekt") version "1.23.4"
}

# 3. No tests yet
# Skip test task temporarily:
# Edit check-fast.sh and comment out:
# ./gradlew testDebugUnitTest
```

### "Task 'spotlessCheck' not found"

**Problem**: Gradle task doesn't exist.

**Solution**:
```bash
# Check available Gradle tasks
./gradlew tasks | grep -i spotless

# If not found, either:
# 1. Add spotless plugin to build.gradle.kts
# 2. Or remove from check-fast.sh:
vim tools/check-fast.sh
# Comment out or remove the spotless line
```

### "Build variant 'debug' not found"

**Problem**: Your project uses different build variants.

**Solution**:
```bash
# Check available variants
./gradlew tasks | grep assemble

# Update check scripts to use your variant
vim tools/check.sh
# Change:
./gradlew assembleDebug
# To:
./gradlew assembleYourVariant
```

### Gradle daemon issues

**Problem**: Gradle commands hang or fail with daemon errors.

**Solution**:
```bash
# Stop Gradle daemon
./gradlew --stop

# Clear Gradle cache
rm -rf ~/.gradle/caches

# Re-run checks
./tools/check-fast.sh
```

## Session Management Issues

### `ai-start.sh` fails to create session

**Problem**: Session file not created in `.ai/sessions/`.

**Solution**:
```bash
# Check directory exists and is writable
ls -la .ai/sessions/
mkdir -p .ai/sessions/  # Create if missing

# Check for SESSION_TEMPLATE.md
ls -la .ai/sessions/SESSION_TEMPLATE.md

# If missing, restore from toolkit
cp tools/ai-dev-toolkit/templates/.ai/sessions/SESSION_TEMPLATE.md .ai/sessions/

# Run with debugging
bash -x tools/ai-start.sh test-feature
```

### `ai-resume.sh` can't find last session

**Problem**: "No sessions found" or picks wrong session.

**Solution**:
```bash
# Check sessions exist
ls -la .ai/sessions/*.md

# Ignore template files
# Sessions should be named: YYYY-MM-DD__feature-name.md

# Manually specify session
# Edit ai-resume.sh or create symlink:
ln -sf .ai/sessions/2026-01-28__myfeature.md .ai/sessions/LAST
```

### Session file has wrong format

**Problem**: Date format or filename is incorrect.

**Solution**:
```bash
# Expected format: 2026-01-28__feature-name.md
# Check date command works:
date +%Y-%m-%d

# If on macOS and date format differs, install coreutils:
brew install coreutils
# Then use: gdate +%Y-%m-%d
```

## Allowlist Validation Issues

### `ai-allowlist-check.sh` always fails

**Problem**: Allowlist check fails even for approved files.

**Solution**:
```bash
# Check if allowlist file exists
cat .ai/allowlist.txt

# If empty or missing, it was never generated from Change Contract
# Allowlist should be created by AI during contract phase

# Manually create for testing:
cat > .ai/allowlist.txt << 'EOF'
app/src/main/java/com/example/Feature.kt
app/src/test/java/com/example/FeatureTest.kt
EOF

# Check git status
git status --short
```

### Allowlist check blocks valid files

**Problem**: Files legitimately part of feature are blocked.

**Solution**:
```bash
# Check exact paths in allowlist
cat .ai/allowlist.txt

# Compare with git changes
git status --short

# Update allowlist if needed (during development):
git diff --name-only >> .ai/allowlist.txt
sort -u .ai/allowlist.txt -o .ai/allowlist.txt
```

### "Not a git repository" in allowlist check

**Problem**: Git commands fail in `ai-allowlist-check.sh`.

**Solution**:
```bash
# Ensure you're in git repo
cd /path/to/project
git rev-parse --show-toplevel

# Re-run from project root
cd $(git rev-parse --show-toplevel)
./tools/ai-allowlist-check.sh
```

## Ticket Generator Issues

### `ticket-generator.sh` shows no files in fuzzy finder

**Problem**: fzf shows empty list when pressing `#`.

**Solution**:
```bash
# Check fzf is installed
which fzf

# Check git ls-files works
git ls-files

# If in subdirectory, cd to root:
cd $(git rev-parse --show-toplevel)
./tools/ticket-generator.sh
```

### Ticket generator TUI is garbled

**Problem**: gum interface displays incorrectly.

**Solution**:
```bash
# Check terminal supports ANSI colors
echo $TERM  # Should be xterm-256color or similar

# Update terminal emulator
# Or set TERM variable:
export TERM=xterm-256color

# Try again
./tools/ticket-generator.sh
```

### Cannot write to `specs/` directory

**Problem**: "Permission denied" when saving ticket.

**Solution**:
```bash
# Check directory exists and is writable
ls -la specs/
mkdir -p specs/

# Check permissions
chmod 755 specs/

# Verify
touch specs/test.md
rm specs/test.md
```

### Ticket file name has invalid characters

**Problem**: Generated ticket has spaces or special chars in filename.

**Solution**:
```bash
# The script should handle this, but if manual:
# Replace spaces with hyphens
# Remove special characters

# Find problematic ticket
ls -la specs/

# Rename
mv "specs/My Feature.md" specs/20260128-my-feature.md
```

## Performance Issues

### Scripts are slow (>30 seconds)

**Problem**: All scripts take too long to execute.

**Solution**:
```bash
# Check git performance
time git status

# Large repo? Add to .gitignore:
echo ".ai/context/" >> .gitignore
echo "build/" >> .gitignore

# Profile script execution
time bash -x tools/ai-context.sh

# Reduce context size (see Context Generation Issues)
```

### Gradle is slow

**Problem**: Quality checks take minutes.

**Solution**:
```bash
# Enable Gradle daemon
echo "org.gradle.daemon=true" >> gradle.properties

# Increase memory
echo "org.gradle.jvmargs=-Xmx4096m" >> gradle.properties

# Enable parallel execution
echo "org.gradle.parallel=true" >> gradle.properties

# Enable configuration cache
./gradlew --configuration-cache check
```

## Permission Issues

### "Operation not permitted"

**Problem**: macOS blocks script execution.

**Solution**:
```bash
# Allow Terminal in System Preferences > Privacy & Security

# Or remove quarantine attribute
xattr -d com.apple.quarantine tools/*.sh

# Grant Terminal full disk access if needed
```

### "Cannot create directory .ai"

**Problem**: Insufficient permissions in project directory.

**Solution**:
```bash
# Check project ownership
ls -la /path/to/project

# Fix ownership if needed
sudo chown -R $USER:$USER /path/to/project

# Or run with sudo (not recommended)
sudo ./tools/install.sh
```

## General Debugging

### Enable verbose output

```bash
# Run any script with debugging
bash -x tools/script-name.sh

# Or add to script temporarily
set -x  # Add after shebang

# Disable after debugging
set +x
```

### Check environment

```bash
# Verify all tools
which git gum fzf bash

# Check versions
git --version
gum --version
fzf --version
bash --version

# Check PATH
echo $PATH

# Check shell
echo $SHELL
```

### Inspect generated files

```bash
# Check AI context
cat .ai/context/AI_CONTEXT.md | head -n 50

# Check session files
ls -la .ai/sessions/
cat .ai/sessions/$(ls -t .ai/sessions/*.md | grep -v TEMPLATE | head -1)

# Check allowlist
cat .ai/allowlist.txt

# Check git status
git status --short
```

## Getting More Help

If issues persist:

1. **Check logs**: Look for error messages in terminal output
2. **Verify installation**: Re-run `install.sh` with clean slate
3. **Test minimal case**: Create new simple Android project and install toolkit
4. **Review configuration**: See [CONFIGURATION.md](CONFIGURATION.md)
5. **Check documentation**: Review [README.md](README.md)

## Common Solutions Summary

| Issue | Quick Fix |
|-------|-----------|
| Git not found | `brew install git` (macOS) or `sudo apt install git` (Linux) |
| gum not found | `brew install gum` or use apt repo |
| fzf not found | `brew install fzf` or `sudo apt install fzf` |
| Permission denied | `chmod +x tools/*.sh` |
| Not a git repo | `git init` |
| Context empty | Check `docs/ai/*.md` files exist |
| Checks fail | Run individual Gradle tasks to debug |
| Scripts slow | Reduce context size, optimize Git repo |
| Allowlist fails | Regenerate from Change Contract |
| TUI garbled | `export TERM=xterm-256color` |
