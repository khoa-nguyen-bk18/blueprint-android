# AI Development Toolkit for Android

A comprehensive toolkit for AI-assisted Android development with structured workflows, automated context generation, and quality gates.

## Features

- **🤖 AI-Assisted Development**: Structured workflow with Change Contracts and session management
- **📝 Ticket Generation**: Interactive TUI wizard for creating structured BA → Dev tickets
- **✅ Quality Gates**: Automated checks for formatting, linting, and testing
- **🔄 Context Management**: Automatic generation of consolidated AI context from project documentation
- **🎯 Session Tracking**: Track development sessions with automatic resume capability
- **🛠️ Validation**: Allowlist checking to ensure changes stay within approved scope

## Quick Start

### Installation

1. **Extract the toolkit** to your project's `tools/` directory:
   ```bash
   cd your-android-project
   mkdir -p tools
   tar -xzf ai-dev-toolkit.tar.gz -C tools/
   ```

2. **Run the installer**:
   ```bash
   cd tools/ai-dev-toolkit
   ./scripts/install.sh
   ```

   The installer will:
   - ✓ Check for git repository (offer to initialize if needed)
   - ✓ Install required CLI tools (`gum`, `fzf`)
   - ✓ Copy scripts to your project's `tools/` directory
   - ✓ Create directory structure (`.ai/`, `docs/ai/`, `specs/`)
   - ✓ Configure project settings interactively
   - ✓ Merge template files with your project
   - ✓ Validate installation by generating AI context

3. **Verify installation**:
   ```bash
   cd ../..  # Return to project root
   ./tools/ai-context.sh
   ```

   If successful, you'll see `.ai/context/AI_CONTEXT.md` generated.

### First AI Session

Start your first AI-assisted development session:

```bash
# Option 1: With GitHub Copilot CLI (automated)
./tools/ai-start-copilot.sh login-feature

# Option 2: Manual workflow (copy/paste into AI tool)
./tools/ai-start.sh login-feature
```

The AI will:
1. Read your project rules and architecture
2. Summarize constraints
3. Create a Change Contract
4. Wait for your `APPROVE_CONTRACT` confirmation
5. Implement changes in slices with automatic quality checks

### Resume a Session

```bash
# Automated with Copilot
./tools/ai-resume-copilot.sh

# Manual workflow
./tools/ai-resume.sh
```

## Prerequisites

### Required

- **Git**: Must be installed and project must be a git repository
- **Bash**: Shell script interpreter
- **Android Project**: Gradle-based Android project

### Recommended CLI Tools

The installer will offer to install these for you:

- **[gum](https://github.com/charmbracelet/gum)**: Interactive TUI framework
  ```bash
  # macOS
  brew install gum
  
  # Linux
  sudo apt install gum
  ```

- **[fzf](https://github.com/junegunn/fzf)**: Fuzzy file finder
  ```bash
  # macOS
  brew install fzf
  
  # Linux
  sudo apt install fzf
  ```

### Optional AI CLI Tools

- **GitHub Copilot CLI**: For automated Copilot integration
- **Gemini CLI**: For automated Gemini integration

## Available Scripts

### AI Workflow Scripts

| Script | Description |
|--------|-------------|
| `ai-start-copilot.sh <feature>` | Start new feature session with Copilot auto-launch |
| `ai-start-gemini.sh <feature>` | Start new feature session with Gemini auto-launch |
| `ai-start.sh <feature>` | Start new feature (manual copy/paste workflow) |
| `ai-resume-copilot.sh` | Resume last session with Copilot |
| `ai-resume-gemini.sh` | Resume last session with Gemini |
| `ai-resume.sh` | Resume last session (manual workflow) |
| `ai-context.sh` | Generate AI context pack only |
| `ai-allowlist-check.sh` | Verify changes match approved Change Contract |

### Quality Check Scripts

| Script | Description |
|--------|-------------|
| `check-fast.sh` | Quick checks: spotless, detekt, lint, unit tests |
| `check.sh` | Full checks: fast checks + debug build |

### Ticket Generation

| Script | Description |
|--------|-------------|
| `ticket-generator.sh` | Interactive wizard for creating structured tickets |

See [ticket-generator-instruction.md](tools/ticket-generator-instruction.md) for details.

## Project Structure

After installation, your project will have:

```
your-project/
├── .ai/
│   ├── allowlist.txt                      # Generated per session
│   ├── decisions.md                       # Architectural decisions
│   ├── context/
│   │   └── AI_CONTEXT.md                 # Generated context pack
│   ├── prompts/
│   │   ├── MASTER_PROMPT.md              # AI protocol instructions
│   │   ├── CHANGE_CONTRACT_TEMPLATE.md   # Contract template
│   │   └── RESUME_PROMPT_TEMPLATE.md     # Resume template
│   └── sessions/
│       ├── SESSION_TEMPLATE.md           # Session template
│       └── 2026-01-28__login-feature.md  # Individual sessions
├── docs/ai/
│   ├── AI_RULES.md                       # Coding rules, architecture
│   ├── PROJECT_MAP.md                    # Module layout, packages
│   ├── DEFINITION_OF_DONE.md            # Quality gates
│   ├── GOLDEN_EXAMPLES.md               # Reference implementations
│   └── WORKFLOW.md                       # Workflow documentation
├── specs/
│   └── 20260128-feature.md              # Generated tickets
└── tools/
    ├── ai-dev-toolkit/                   # This toolkit
    ├── ai-*.sh                           # AI workflow scripts
    ├── check*.sh                         # Quality check scripts
    └── ticket-generator.sh               # Ticket wizard
```

## Workflow

### 1. Start a Feature

```bash
./tools/ai-start-copilot.sh user-authentication
```

This creates `.ai/sessions/2026-01-28__user-authentication.md` and launches AI with full context.

### 2. AI Generates Change Contract

The AI reads your project rules and creates a contract listing:
- Files to modify
- Files to create
- Acceptance criteria
- Testing requirements

### 3. Approve Contract

Reply with: `APPROVE_CONTRACT`

The AI proceeds with implementation.

### 4. Incremental Development

The AI works in slices, running `./tools/check-fast.sh` after each change to validate:
- Code formatting (spotless)
- Static analysis (detekt)
- Linting (Android Lint)
- Unit tests

### 5. Validate Scope

```bash
./tools/ai-allowlist-check.sh
```

Ensures all changes are within the approved Change Contract scope.

### 6. Resume Later

```bash
./tools/ai-resume-copilot.sh
```

Picks up where you left off with full session history.

## Configuration

After installation, customize these files for your project:

### Critical Files (Review First)

1. **[docs/ai/AI_RULES.md](docs/ai/AI_RULES.md)**
   - Architecture boundaries (MVVM, MVI, etc.)
   - File placement rules
   - Naming conventions
   - Error handling patterns

2. **[docs/ai/PROJECT_MAP.md](docs/ai/PROJECT_MAP.md)**
   - Module structure
   - Package layout
   - Key entry points
   - Golden examples

3. **[docs/ai/GOLDEN_EXAMPLES.md](docs/ai/GOLDEN_EXAMPLES.md)**
   - Point to your best ViewModel
   - Best Screen/Composable
   - Best Repository
   - Best test examples

See [CONFIGURATION.md](CONFIGURATION.md) for detailed customization guide.

## Shell Aliases (Optional)

Add to `~/.bashrc` or `~/.zshrc`:

```bash
alias ai-start="./tools/ai-start-copilot.sh"
alias ai-resume="./tools/ai-resume-copilot.sh"
alias ai-check="./tools/check-fast.sh"
alias ai-ticket="./tools/ticket-generator.sh"
```

Then use:
```bash
ai-start login-feature
ai-resume
ai-check
ai-ticket
```

## Troubleshooting

### Common Issues

**"Command not found: gum"**
```bash
# macOS
brew install gum

# Linux
sudo apt install gum
```

**"Not a git repository"**
```bash
git init
```

**"ai-context.sh fails to generate context"**
- Check that `docs/ai/AI_RULES.md` exists
- Check that `.ai/prompts/MASTER_PROMPT.md` exists
- Review error messages in terminal

**"check-fast.sh fails"**
- Ensure you have Gradle wrapper: `./gradlew`
- Run individual checks to isolate issue:
  ```bash
  ./gradlew spotlessCheck
  ./gradlew detekt
  ./gradlew lintDebug
  ./gradlew testDebugUnitTest
  ```

See [TROUBLESHOOTING.md](TROUBLESHOOTING.md) for more solutions.

## Architecture Overview

This toolkit implements a structured AI-assisted development workflow:

1. **Context Generation**: Consolidates project docs, rules, and session history
2. **Change Contract**: Explicit agreement on scope before code generation
3. **Incremental Development**: Small slices with validation after each
4. **Quality Gates**: Automated checks prevent regressions
5. **Session Management**: Track progress and resume anytime

### Key Principles

- **No code before contract**: AI must get approval before editing
- **Tool-truth**: Changes are valid only if checks pass
- **No architectural drift**: New patterns require explicit decisions
- **Prefer modification**: Extend existing code over creating new files

## Examples

### Example Session Flow

```bash
# 1. Start feature
./tools/ai-start-copilot.sh add-settings-screen

# AI generates context and summarizes rules
# AI creates Change Contract

# 2. Approve
APPROVE_CONTRACT

# AI implements:
# - Creates SettingsScreen.kt
# - Creates SettingsViewModel.kt
# - Updates navigation
# - Runs ./tools/check-fast.sh after each change

# 3. Validate scope
./tools/ai-allowlist-check.sh

# 4. Session complete
# File saved: .ai/sessions/2026-01-28__add-settings-screen.md
```

### Example Ticket Generation

```bash
./tools/ticket-generator.sh

# Interactive wizard:
# 1. Select template: Feature Development
# 2. Enter title: User Login Screen
# 3. Describe feature (use # to reference files)
# 4. Define acceptance criteria
# 5. Add technical notes

# Output: specs/20260128-user-login-screen.md
```

## Integration with Other Projects

This toolkit is designed for **Android projects** using:
- Gradle build system
- Jetpack Compose (recommended)
- Kotlin
- MVVM/MVI architecture

The quality check scripts (`check-fast.sh`, `check.sh`) use Android-specific Gradle tasks:
- `spotlessCheck` (Kotlin formatting)
- `detekt` (static analysis)
- `lintDebug` (Android Lint)
- `testDebugUnitTest` (unit tests)
- `assembleDebug` (build APK)

For non-Android projects, you'll need to customize these scripts. See [CONFIGURATION.md](CONFIGURATION.md#customizing-quality-checks).

## Contributing

This toolkit is project-specific but designed to be portable. If you adapt it for your project:

1. Customize `docs/ai/*` for your architecture
2. Update quality check scripts for your build system
3. Add your best-in-repo examples to `GOLDEN_EXAMPLES.md`

## License

[Your License Here]

## Support

For issues specific to this toolkit:
1. Check [TROUBLESHOOTING.md](TROUBLESHOOTING.md)
2. Review [CONFIGURATION.md](CONFIGURATION.md)
3. Check that all prerequisites are installed

For project-specific issues, refer to your project's documentation.

---

**Ready to start?** Run `./scripts/install.sh` and begin AI-assisted development! 🚀
