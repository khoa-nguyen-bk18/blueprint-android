# Session: YYYY-MM-DD — Feature: <name>

## Goal
- ...

## Current Status
- Phase: Abstract | Flow | UI | Contract Approved | Slice N | Validation | Done
- Last checkpoint commit: <hash>
- Last stable checks: check-fast PASS, check PASS

## Approved Change Contract (LOCKED)
### Modify
- path:
### Create
- path:
### No-touch
- ...
### Must pass
- tools/check-fast.sh
- tools/check.sh

## Decisions (why)
- Decision:
  - Rationale:
  - Alternatives:

## Work Done (chronological)
1) Slice 1 — ...
   - Commit(s):
2) Slice 2 — ...
   - Commit(s):

## Command Outputs (paste failures here)
- check-fast:
- check:

## Next Steps (exact)
1) ...
2) ...

## Resume Prompt (paste into AI)
Read docs/ai/*.
Last checkpoint: <hash>.
Current phase: <...>.
Contract: (paste).
Next steps: (paste).
Do not touch files outside allowlist/contract without revising contract.
