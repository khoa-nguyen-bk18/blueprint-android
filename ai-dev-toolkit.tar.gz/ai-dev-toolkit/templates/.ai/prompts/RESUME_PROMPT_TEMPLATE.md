Read docs/ai/*.

We are continuing feature: <name>.
Last checkpoint commit: <hash>.
Current phase: <phase>.

Approved Change Contract:
<paste contract here>

Next steps:
1) ...
2) ...

Rules:
- Do not touch files outside the Change Contract / .ai/allowlist.txt.
- If more files are needed, propose an updated Change Contract first.
