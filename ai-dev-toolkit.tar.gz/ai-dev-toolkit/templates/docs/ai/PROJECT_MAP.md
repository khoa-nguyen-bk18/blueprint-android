# Project Map

Update this file once so AI can consistently place code correctly.

**Project:** {{PROJECT_NAME}}  
**Base Package:** {{PACKAGE_NAME}}

## Modules
{{MODULES}}

## Package layout
- `{{PACKAGE_NAME}}`
  {{PACKAGE_STRUCTURE}}

## Key entry points
{{KEY_ENTRY_POINTS}}

## Golden examples
Point AI to your best implementations:
{{GOLDEN_EXAMPLES}}
