#!/usr/bin/env bash

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}ℹ${NC} $1"
}

log_success() {
    echo -e "${GREEN}✓${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

log_error() {
    echo -e "${RED}✗${NC} $1"
}

# Get the directory where this script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
TOOLKIT_ROOT="$( cd "$SCRIPT_DIR/.." && pwd )"

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║                                                                ║"
echo "║        AI Development Toolkit - Installation Wizard           ║"
echo "║                  For Android Projects                          ║"
echo "║                                                                ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

# Check if running from correct location
if [[ ! -d "$TOOLKIT_ROOT/templates" ]] || [[ ! -d "$TOOLKIT_ROOT/tools" ]]; then
    log_error "Installation error: Cannot find toolkit structure."
    log_error "Expected to find 'templates/' and 'tools/' directories."
    log_error "Please run this script from the ai-dev-toolkit/scripts/ directory."
    exit 1
fi

# Step 1: Determine target project directory
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Step 1: Project Directory"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Default to parent directory if toolkit is in project's tools/ai-dev-toolkit/
if [[ "$TOOLKIT_ROOT" == */tools/ai-dev-toolkit ]]; then
    DEFAULT_PROJECT_ROOT="$( cd "$TOOLKIT_ROOT/../.." && pwd )"
    log_info "Detected toolkit location inside project tools/ directory"
    log_info "Default project root: $DEFAULT_PROJECT_ROOT"
    echo ""
    read -p "Use this as project root? (Y/n): " use_default
    if [[ "${use_default,,}" == "n" ]]; then
        read -p "Enter project root directory: " PROJECT_ROOT
        PROJECT_ROOT="${PROJECT_ROOT/#\~/$HOME}"
    else
        PROJECT_ROOT="$DEFAULT_PROJECT_ROOT"
    fi
else
    read -p "Enter target project root directory: " PROJECT_ROOT
    PROJECT_ROOT="${PROJECT_ROOT/#\~/$HOME}"
fi

# Expand and validate project directory
PROJECT_ROOT="$(cd "$PROJECT_ROOT" 2>/dev/null && pwd)" || {
    log_error "Invalid project directory: $PROJECT_ROOT"
    exit 1
}

log_success "Project root: $PROJECT_ROOT"
echo ""

# Step 2: Check Git repository
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Step 2: Git Repository Check"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

if ! command -v git &> /dev/null; then
    log_error "Git is not installed!"
    log_error "Please install git and try again."
    exit 1
fi

cd "$PROJECT_ROOT"

if ! git rev-parse --git-dir > /dev/null 2>&1; then
    log_warning "This directory is not a git repository."
    read -p "Initialize git repository? (Y/n): " init_git
    if [[ "${init_git,,}" != "n" ]]; then
        git init
        log_success "Git repository initialized"
    else
        log_warning "Skipping git initialization. Some tools may not work correctly."
    fi
else
    log_success "Git repository detected"
fi
echo ""

# Step 3: Check and install CLI dependencies
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Step 3: CLI Dependencies (gum, fzf)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Detect OS
OS="unknown"
if [[ "$OSTYPE" == "darwin"* ]]; then
    OS="macos"
    PKG_MANAGER="brew"
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    OS="linux"
    if command -v apt-get &> /dev/null; then
        PKG_MANAGER="apt"
    elif command -v yum &> /dev/null; then
        PKG_MANAGER="yum"
    else
        PKG_MANAGER="unknown"
    fi
else
    log_warning "Unsupported operating system: $OSTYPE"
fi

log_info "Detected OS: $OS (package manager: $PKG_MANAGER)"
echo ""

# Function to install package
install_package() {
    local package=$1
    local brew_name=${2:-$package}
    local apt_name=${3:-$package}
    
    if command -v "$package" &> /dev/null; then
        log_success "$package is already installed ($(command -v "$package"))"
        return 0
    fi
    
    log_warning "$package is not installed"
    read -p "Install $package now? (Y/n): " install_pkg
    
    if [[ "${install_pkg,,}" == "n" ]]; then
        log_warning "Skipping $package installation. Some features may not work."
        return 1
    fi
    
    log_info "Installing $package..."
    
    case "$PKG_MANAGER" in
        brew)
            if ! command -v brew &> /dev/null; then
                log_error "Homebrew is not installed. Please install from https://brew.sh/"
                return 1
            fi
            brew install "$brew_name"
            ;;
        apt)
            sudo apt-get update
            sudo apt-get install -y "$apt_name"
            ;;
        yum)
            sudo yum install -y "$apt_name"
            ;;
        *)
            log_error "Cannot install $package automatically. Please install manually."
            return 1
            ;;
    esac
    
    if command -v "$package" &> /dev/null; then
        log_success "$package installed successfully"
        return 0
    else
        log_error "Installation of $package failed"
        return 1
    fi
}

# Install gum and fzf
GUM_INSTALLED=false
FZF_INSTALLED=false

if install_package "gum" "gum" "gum"; then
    GUM_INSTALLED=true
fi

if install_package "fzf" "fzf" "fzf"; then
    FZF_INSTALLED=true
fi

echo ""

# Step 4: Copy toolkit to project
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Step 4: Copy Toolkit to Project"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Check if we need to copy toolkit (if not already in place)
if [[ "$TOOLKIT_ROOT" != "$PROJECT_ROOT/tools/ai-dev-toolkit" ]]; then
    log_info "Copying toolkit to $PROJECT_ROOT/tools/ai-dev-toolkit/"
    mkdir -p "$PROJECT_ROOT/tools"
    
    if [[ -d "$PROJECT_ROOT/tools/ai-dev-toolkit" ]]; then
        log_warning "Toolkit directory already exists"
        read -p "Overwrite existing toolkit? (y/N): " overwrite
        if [[ "${overwrite,,}" != "y" ]]; then
            log_info "Using existing toolkit installation"
        else
            rm -rf "$PROJECT_ROOT/tools/ai-dev-toolkit"
            cp -r "$TOOLKIT_ROOT" "$PROJECT_ROOT/tools/ai-dev-toolkit"
            log_success "Toolkit copied"
        fi
    else
        cp -r "$TOOLKIT_ROOT" "$PROJECT_ROOT/tools/ai-dev-toolkit"
        log_success "Toolkit copied"
    fi
    
    TOOLKIT_ROOT="$PROJECT_ROOT/tools/ai-dev-toolkit"
else
    log_success "Toolkit already in correct location"
fi

# Copy scripts to tools/ directory
log_info "Setting up tools/ scripts..."
mkdir -p "$PROJECT_ROOT/tools"

for script in "$TOOLKIT_ROOT/tools"/*.sh; do
    script_name=$(basename "$script")
    target="$PROJECT_ROOT/tools/$script_name"
    
    if [[ -f "$target" ]] && ! cmp -s "$script" "$target"; then
        log_warning "$(basename "$script") already exists and differs"
        read -p "Overwrite $script_name? (y/N): " overwrite
        if [[ "${overwrite,,}" == "y" ]]; then
            cp "$script" "$target"
            chmod +x "$target"
            log_success "Updated $script_name"
        fi
    elif [[ ! -f "$target" ]]; then
        cp "$script" "$target"
        chmod +x "$target"
        log_success "Installed $script_name"
    fi
done

# Copy ticket generator instruction
if [[ -f "$TOOLKIT_ROOT/tools/ticket-generator-instruction.md" ]]; then
    cp "$TOOLKIT_ROOT/tools/ticket-generator-instruction.md" "$PROJECT_ROOT/tools/"
fi

echo ""

# Step 5: Create directory structure
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Step 5: Create Directory Structure"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

mkdir -p "$PROJECT_ROOT/.ai/prompts"
mkdir -p "$PROJECT_ROOT/.ai/sessions"
mkdir -p "$PROJECT_ROOT/.ai/context"
mkdir -p "$PROJECT_ROOT/docs/ai"
mkdir -p "$PROJECT_ROOT/specs"

log_success "Created directory structure"
echo ""

# Step 6: Interactive project configuration (if gum is available)
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Step 6: Project Configuration"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

if [[ "$GUM_INSTALLED" == true ]]; then
    log_info "Interactive configuration with gum"
    echo ""
    
    PROJECT_NAME=$(gum input --placeholder "Project name (e.g., MyAwesomeApp)" --value "")
    PACKAGE_NAME=$(gum input --placeholder "Base package (e.g., com.example.myapp)" --value "")
    ARCHITECTURE=$(gum choose "MVVM" "MVI" "MVP" "Clean Architecture" "Other")
    
    echo ""
    log_info "Enter key modules (one per line, empty line to finish):"
    MODULES=""
    while true; do
        MODULE=$(gum input --placeholder "Module name (or press Enter to finish)" --value "")
        if [[ -z "$MODULE" ]]; then
            break
        fi
        if [[ -z "$MODULES" ]]; then
            MODULES="- \`:$MODULE\`"
        else
            MODULES="$MODULES"$'\n'"- \`:$MODULE\`"
        fi
    done
    
    if [[ -z "$MODULES" ]]; then
        MODULES="- \`:app\` — Android application module (UI, navigation, DI bootstrap)"
    fi
    
else
    log_warning "gum not available. Using manual input."
    echo ""
    
    read -p "Project name (e.g., MyAwesomeApp): " PROJECT_NAME
    read -p "Base package (e.g., com.example.myapp): " PACKAGE_NAME
    read -p "Architecture (MVVM/MVI/MVP/Clean): " ARCHITECTURE
    
    MODULES="- \`:app\` — Android application module (UI, navigation, DI bootstrap)"
fi

# Set defaults if empty
PROJECT_NAME="${PROJECT_NAME:-MyAndroidApp}"
PACKAGE_NAME="${PACKAGE_NAME:-com.example.app}"
ARCHITECTURE="${ARCHITECTURE:-MVVM}"

log_success "Configuration captured"
echo ""

# Step 7: Merge templates
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Step 7: Merge Templates"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

MARKER="# --- ADDED BY AI-DEV-TOOLKIT INSTALLER ---"

# Function to merge template with placeholders
merge_template() {
    local template_file=$1
    local target_file=$2
    local should_customize=$3
    
    if [[ -f "$target_file" ]]; then
        log_warning "$(basename "$target_file") already exists"
        
        # Check if already has our marker
        if grep -q "ADDED BY AI-DEV-TOOLKIT INSTALLER" "$target_file"; then
            log_info "File already contains toolkit content, skipping"
            return 0
        fi
        
        read -p "Merge with existing file? (Y/n): " merge
        if [[ "${merge,,}" == "n" ]]; then
            log_info "Skipping $(basename "$target_file")"
            return 0
        fi
        
        # Backup existing file
        cp "$target_file" "${target_file}.backup"
        log_info "Created backup: ${target_file}.backup"
        
        # Append new content with marker
        {
            echo ""
            echo "$MARKER"
            echo ""
            if [[ "$should_customize" == "true" ]]; then
                # Use perl for multi-line replacements (sed can't handle newlines)
                perl -pe "
                    s/\{\{PROJECT_NAME\}\}/$PROJECT_NAME/g;
                    s/\{\{PACKAGE_NAME\}\}/$PACKAGE_NAME/g;
                    s/\{\{ARCHITECTURE\}\}/$ARCHITECTURE/g;
                " "$template_file" | \
                perl -pe "s|\{\{MODULES\}\}|$MODULES|g" | \
                perl -pe "s|\{\{PACKAGE_STRUCTURE\}\}|  - \\\`ui/<feature>/\\\` — screen + ViewModel + UI state\\n  - \\\`data/\\\` — repositories, data sources, Room\\n  - \\\`di/\\\` — Hilt modules|g" | \
                perl -pe "s|\{\{KEY_ENTRY_POINTS\}\}|- Application class: \\\`${PACKAGE_NAME}.Application\\\`\\n- Main activity: \\\`${PACKAGE_NAME}.MainActivity\\\`|g" | \
                perl -pe "s|\{\{GOLDEN_EXAMPLES\}\}|- Best ViewModel: (update after project setup)\\n- Best Screen: (update after project setup)\\n- Best Repository: (update after project setup)|g"
            else
                cat "$template_file"
            fi
        } >> "$target_file"
        
        log_success "Merged $(basename "$target_file")"
    else
        # Create new file with customization
        if [[ "$should_customize" == "true" ]]; then
            # Use perl for multi-line replacements (sed can't handle newlines)
            perl -pe "
                s/\{\{PROJECT_NAME\}\}/$PROJECT_NAME/g;
                s/\{\{PACKAGE_NAME\}\}/$PACKAGE_NAME/g;
                s/\{\{ARCHITECTURE\}\}/$ARCHITECTURE/g;
            " "$template_file" | \
            perl -pe "s|\{\{MODULES\}\}|$MODULES|g" | \
            perl -pe "s|\{\{PACKAGE_STRUCTURE\}\}|  - \\\`ui/<feature>/\\\` — screen + ViewModel + UI state\\n  - \\\`data/\\\` — repositories, data sources, Room\\n  - \\\`di/\\\` — Hilt modules|g" | \
            perl -pe "s|\{\{KEY_ENTRY_POINTS\}\}|- Application class: \\\`${PACKAGE_NAME}.Application\\\`\\n- Main activity: \\\`${PACKAGE_NAME}.MainActivity\\\`|g" | \
            perl -pe "s|\{\{GOLDEN_EXAMPLES\}\}|- Best ViewModel: (update after project setup)\\n- Best Screen: (update after project setup)\\n- Best Repository: (update after project setup)|g" \
            > "$target_file"
        else
            cp "$template_file" "$target_file"
        fi
        
        log_success "Created $(basename "$target_file")"
    fi
}

# Merge .ai/prompts/ files
for prompt in "$TOOLKIT_ROOT/templates/.ai/prompts"/*.md; do
    merge_template "$prompt" "$PROJECT_ROOT/.ai/prompts/$(basename "$prompt")" false
done

# Merge .ai/sessions/SESSION_TEMPLATE.md
merge_template "$TOOLKIT_ROOT/templates/.ai/sessions/SESSION_TEMPLATE.md" \
               "$PROJECT_ROOT/.ai/sessions/SESSION_TEMPLATE.md" false

# Merge .ai/decisions.md
if [[ ! -f "$PROJECT_ROOT/.ai/decisions.md" ]]; then
    cp "$TOOLKIT_ROOT/templates/.ai/decisions.md.template" "$PROJECT_ROOT/.ai/decisions.md"
    log_success "Created .ai/decisions.md"
fi

# Merge docs/ai/ files (with customization for AI_RULES and PROJECT_MAP)
merge_template "$TOOLKIT_ROOT/templates/docs/ai/AI_RULES.md" \
               "$PROJECT_ROOT/docs/ai/AI_RULES.md" true

merge_template "$TOOLKIT_ROOT/templates/docs/ai/PROJECT_MAP.md" \
               "$PROJECT_ROOT/docs/ai/PROJECT_MAP.md" true

# Copy other docs/ai files without customization
for doc in DEFINITION_OF_DONE.md GOLDEN_EXAMPLES.md WORKFLOW.md; do
    if [[ -f "$TOOLKIT_ROOT/templates/docs/ai/$doc" ]]; then
        merge_template "$TOOLKIT_ROOT/templates/docs/ai/$doc" \
                       "$PROJECT_ROOT/docs/ai/$doc" false
    fi
done

echo ""

# Step 8: Validation
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Step 8: Validation"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

cd "$PROJECT_ROOT"

# Test ai-context.sh
log_info "Testing ai-context.sh..."
if [[ -x "$PROJECT_ROOT/tools/ai-context.sh" ]]; then
    if "$PROJECT_ROOT/tools/ai-context.sh" > /dev/null 2>&1; then
        log_success "ai-context.sh executed successfully"
        
        if [[ -f "$PROJECT_ROOT/.ai/context/AI_CONTEXT.md" ]]; then
            log_success "AI_CONTEXT.md generated successfully"
            CONTEXT_SIZE=$(wc -l < "$PROJECT_ROOT/.ai/context/AI_CONTEXT.md")
            log_info "Context file size: $CONTEXT_SIZE lines"
        else
            log_warning "AI_CONTEXT.md was not generated"
        fi
    else
        log_warning "ai-context.sh completed with warnings (check manually)"
    fi
else
    log_error "ai-context.sh is not executable"
fi

echo ""

# Installation summary
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║                                                                ║"
echo "║              Installation Complete! 🎉                         ║"
echo "║                                                                ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

echo "Next Steps:"
echo ""
echo "1. Review and customize your configuration:"
echo "   - $PROJECT_ROOT/docs/ai/AI_RULES.md"
echo "   - $PROJECT_ROOT/docs/ai/PROJECT_MAP.md"
echo "   - $PROJECT_ROOT/docs/ai/GOLDEN_EXAMPLES.md"
echo ""
echo "2. Start your first AI-assisted session:"
echo "   cd $PROJECT_ROOT"
echo "   ./tools/ai-start-copilot.sh my-feature"
echo ""
echo "3. Or generate context manually:"
echo "   ./tools/ai-start.sh my-feature"
echo ""
echo "4. Available commands:"
echo "   ./tools/ai-start-copilot.sh <feature>  - Start new feature (auto Copilot)"
echo "   ./tools/ai-resume-copilot.sh           - Resume last session"
echo "   ./tools/check-fast.sh                  - Run quality checks"
echo "   ./tools/ticket-generator.sh            - Create structured tickets"
echo ""

if [[ "$GUM_INSTALLED" == false ]] || [[ "$FZF_INSTALLED" == false ]]; then
    echo "⚠️  Some tools require CLI dependencies that were not installed:"
    [[ "$GUM_INSTALLED" == false ]] && echo "   - gum (for interactive prompts)"
    [[ "$FZF_INSTALLED" == false ]] && echo "   - fzf (for file searching in ticket-generator)"
    echo ""
fi

echo "📚 Documentation:"
echo "   README: $TOOLKIT_ROOT/README.md"
echo "   Configuration: $TOOLKIT_ROOT/CONFIGURATION.md"
echo "   Troubleshooting: $TOOLKIT_ROOT/TROUBLESHOOTING.md"
echo ""

log_success "Installation completed successfully!"
